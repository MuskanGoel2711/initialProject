import React from 'react';
import { Text, View } from 'react-native';

const Random = () => {
  return (
    <View>
      <Text>Random</Text>
    </View>
  )
}

export default Random;