const sizes = {
    buttonText: 16,
    header: 23,
    description: 16,
    inputText: 15,
    headerText: 18,
    errorText: 13,
    otpInput: 18,
    modalText: 18,
    textFlatList: 15,
    labelTopTabBar: 12
}

export default sizes;