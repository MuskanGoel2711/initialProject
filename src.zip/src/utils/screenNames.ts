enum ScreenNames{
    Splash= 'Splash',
    Tutorial = 'Tutorial',
    HomeScreen= 'HomeScreen',
    Login= 'Login',
    SignUp= 'SignUp',
    ForgotPassword= 'ForgotPassword',
    AddShipment='AddShipment',
    Setting='Setting',
    VerifyOtp='VerifyOtp',
    Random='Random',
    GeneralDetails= 'GeneralDetails',
    Shipment1Details= 'Shipment1Details',
    PickUpDetails= 'PickUpDetails'
  } ;
  
  export {ScreenNames};