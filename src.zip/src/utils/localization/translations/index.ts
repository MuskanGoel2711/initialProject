export { default as en } from "./en.json";
export { default as fr } from "./fr.json";
export { default as ur } from "./ur.json";
export { default as ru } from "./ru.json";
export { default as hn } from "./hn.json";